import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { baseurl } from "../Basurl/Baseurl";

export const GetPatientTreatments = createAsyncThunk(
  "PatientTreatments/GetPatientTreatments",
  async (object, { rejectWithValue }) => {
    try {
      let response;
      try {
        response = await axios.get(`${baseurl}get_patient/${object.id}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        });
      } catch (getErr) {
        if (getErr.response?.status === 404) {
          response = await axios.get(
            `${baseurl}user/get_particular_patient/${object.id}`,
            {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
                "Content-Type": "application/json",
              },
            }
          );
        } else {
          throw getErr;
        }
      }
      return response.data.detail || response.data.data || response.data; // Success response
    } catch (err) {
      console.error("Error fetching patient details:", err.response?.data?.message || err.message);
      return rejectWithValue(
        err.response?.data
          ? {
              ...err.response.data,
              status: err.response.status,
              statusCode: err.response.status,
            }
          : {
              status: err.response?.status,
              statusCode: err.response?.status,
              message: err.message || "An unknown error occurred",
            }
      );
    }
  }
);
export const AddTretmentForPatient = createAsyncThunk(
  "PatientTreatments/AddTretmentForPatient",
  async (object, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${baseurl}create_treatment`, object, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "Content-Type": "application/json",
        },
      });
      return response.data; // Success response
    } catch (error) {
      console.error("Error adding staff user:", error.response?.data?.message);
      return rejectWithValue(
        error.response?.data || { message: "An unknown error occurred" }
      );
    }
  }
);
export const AddHospitalForPatient = createAsyncThunk(
  "PatientTreatments/AddHospitalForPatient",
  async (object, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${baseurl}assign_patient_to_hospital/${object.id}`,
        object,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      );

      return response.data;
    } catch (error) {
      const backend = error.response?.data;

      // CASE 1: backend.errors is an object { field: ["error1","error2"] }
      if (backend?.errors && typeof backend.errors === "object") {
        const flatErrors = Object.values(backend.errors).flat();
        return rejectWithValue(flatErrors);
      }

      // CASE 2: backend.errors is an array: ["err1","err2"]
      if (Array.isArray(backend?.errors)) {
        return rejectWithValue(backend.errors);
      }

      // CASE 3: single message
      if (backend?.message) {
        return rejectWithValue([backend.message]);
      }

      // CASE 4: fallback
      return rejectWithValue(["An unknown error occurred"]);
    }
  }
);

// export const AddHospitalForPatient = createAsyncThunk(
//   "PatientTreatments/AddHospitalForPatient",
//   async (object, { rejectWithValue }) => {
//     try {
//       const response = await axios.post(
//         `${baseurl}assign_patient_to_hospital/${object.id}`,
//         object,
//         {
//           headers: {
//             Authorization: `Bearer ${localStorage.getItem("token")}`,
//             "Content-Type": "application/json",
//           },
//         }
//       );
//       return response.data; // Success response
//     } catch (error) {
//       console.error("Error adding staff user:", error.response?.data?.message);
//       return rejectWithValue(
//         error.response?.data || { message: "An unknown error occurred" }
//       );
//     }
//   }
// );
export const AppointmentForPatient = createAsyncThunk(
  "PatientTreatments/AppointmentForPatient",
  async (object, { rejectWithValue }) => {
    console.log(object);
    const hospitalId =
      object.hospital_id ?? object.hospitalId ?? object.hospitalID ?? "";
    const payload = {
      ...object,
      hospital_id: hospitalId,
      hospitalId,
    };
    try {
      const response = await axios.post(
        `${baseurl}create_appointment/${localStorage.getItem("_id")}`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      );
      return response.data; // Success response
    } catch (error) {
      console.error("Error adding staff user:", error.response?.data?.message);
      return rejectWithValue(
        error.response?.data || { message: "An unknown error occurred" }
      );
    }
  }
);

export const AddKysDetail = createAsyncThunk(
  "PatientTreatments/AddKysDetail",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${baseurl}patient_Kyc_details/${formData.id}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
            "Content-Type": "multipart/form-data",
          },
        }
      );
      return response.data; // Success response
    } catch (error) {
      console.error("Error adding staff user:", error.response?.data?.message);
      return rejectWithValue(
        error.response?.data || { message: "An unknown error occurred" }
      );
    }
  }
);

export const ExtraServices = createAsyncThunk(
  "PatientTreatments/ExtraServices",
  async (object, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${baseurl}patient_extra_service/${object.id}`,
        object,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      );
      return response.data; // Success response
    } catch (error) {
      console.error("Error adding staff user:", error.response?.data?.message);
      return rejectWithValue(
        error.response?.data || { message: "An unknown error occurred" }
      );
    }
  }
);
// export const AddNewTretmentPayment = createAsyncThunk(
//   "PatientTreatments/AddNewTretmentPayment",
//   async (object, { rejectWithValue }) => {
//     try {
//       const response = await axios.post(
//         `${baseurl}add_new_treatment_payment/${object.id}`,
//         object,
//         {
//           headers: {
//             Authorization: `Bearer ${localStorage.getItem("token")}`,
//             "Content-Type": "application/json",
//           },
//         }
//       );
//       return response.data;
//     } catch (error) {
//       return rejectWithValue(
//         error.response?.data?.message || "An unknown error occurred"
//       );
//     }
//   }
// );

// export const AddNewTretmentPayment = createAsyncThunk(
//   "PatientTreatments/AddNewTretmentPayment",
//   async (object, { rejectWithValue }) => {
//     try {
//       const response = await axios.post(
//         `${baseurl}add_new_treatment_payment/${object.id}`,
//         object,
//         {
//           headers: {
//             Authorization: `Bearer ${localStorage.getItem("token")}`,
//             "Content-Type": "application/json",
//           },
//         }
//       );
//       return response.data; // Success response
//     } catch (error) {
//       console.error("Error adding staff user:", error.response?.data?.message);
//       return rejectWithValue(
//         error.response?.data || { message: "An unknown error occurred" }
//       );
//     }
//   }
// );
// export const TritmentStatus = createAsyncThunk(
//     "PatientTreatments/TritmentStatus",
//     async (object, { rejectWithValue }) => {
//       try {
//         const token = localStorage.getItem("token");

//         if (!token) {
//           throw new Error("Authorization token is missing");
//         }

//         const response = await axios.post(
//           `${baseurl}update_patient_treatment_status/${object.id}`,
//           { status: object.status }, // Ensure you're passing the correct payload
//           {
//             headers: {
//               Authorization: `Bearer ${token}`,
//               "Content-Type": "application/json",
//             },
//           }
//         );

//         return response.data; // Success response
//       } catch (err) {
//         console.error("Error editing Enquiry status:", err.response?.data?.message);
//         return rejectWithValue(
//           err.response?.data || { message: "An unknown error occurred" }
//         );
//       }
//     }
//   );
export const AddNewTretmentPayment = createAsyncThunk(
  "PatientTreatments/AddNewTretmentPayment",
  async (formData, { rejectWithValue }) => {
    try {
      const paidAmount = formData.get("paid_amount");
      if (paidAmount !== null && paidAmount !== "") {
        const trimmed = String(paidAmount).trim();
        const num = Number(trimmed);
        if (!isNaN(num)) {
          formData.set("paid_amount", trimmed);
        }
      }
      const response = await axios.post(
        `${baseurl}add_new_treatment_payment/${formData.get("id")}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "An unknown error occurred"
      );
    }
  }
);
export const ApproveTreatmentPayment = createAsyncThunk(
  "PatientTreatments/ApproveTreatmentPayment",
  async ({ treatment_id, payment_id }, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${baseurl}approve_treatment_payment/${treatment_id}/${payment_id}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to approve payment"
      );
    }
  }
);
export const RejectTreatmentPayment = createAsyncThunk(
  "PatientTreatments/RejectTreatmentPayment",
  async ({ treatment_id, payment_id, notes }, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${baseurl}reject_treatment_payment/${treatment_id}/${payment_id}`,
        { notes },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to reject payment"
      );
    }
  }
);
const PatientTreatmentSlice = createSlice({
  name: "PatientTreatments",
  initialState: {
    PatientTreatments: {},
    loading: false,
    error: null,
  },
  reducers: {
    addPatientTre: (state, action) => {
      state.PatientTreatmentSlice.push(action.payload);
    },
    addHospital: (state, action) => {
      state.PatientTreatmentSlice.push(action.payload);
    },
    addAppointment: (state, action) => {
      state.PatientTreatmentSlice.push(action.payload);
    },
    addKYc: (state, action) => {
      state.PatientTreatmentSlice.push(action.payload);
    },
    Exservice: (state, action) => {
      state.PatientTreatmentSlice.push(action.payload);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(GetPatientTreatments.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(GetPatientTreatments.fulfilled, (state, action) => {
        state.loading = false;
        state.PatientTreatments = action.payload;
      })
      .addCase(GetPatientTreatments.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });

    //Status Enquiry update
    //   .addCase(TritmentStatus.pending, (state) => {
    //     state.loading = true;
    //     state.error = null;
    //   })
    //   .addCase(TritmentStatus.fulfilled, (state, action) => {
    //     state.loading = false;
    //     const updatedUser = action.payload;

    //     // Update the staff list with the edited user
    //     state.PatientTreatments = state.PatientTreatments.
    //     treatments
    //     map((user) =>
    //       user.patientId
    //     === updatedUser.patientId
    //     ? updatedUser : user
    //     );
    //   })
    //   .addCase(TritmentStatus.rejected, (state, action) => {
    //     state.loading = false;
    //     state.error = action.payload;
    //   })
  },
});
export default PatientTreatmentSlice.reducer;
export const { addPatientTre } = PatientTreatmentSlice.actions;
export const { addHospital } = PatientTreatmentSlice.actions;
export const { addAppointment } = PatientTreatmentSlice.actions;
export const { addKYc } = PatientTreatmentSlice.actions;
export const { Exservice } = PatientTreatmentSlice.actions;
