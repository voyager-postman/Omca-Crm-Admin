import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Swal from "sweetalert2";
import { Formik, Field, ErrorMessage, Form } from "formik";
import * as Yup from "yup";
import { AddHospitalData } from "../../reducer/HospitalSlice";
import { useNavigate } from "react-router-dom";
import hospital from "../../img/hospital 3.jpg";
import { GetAllCountries2 } from "../../reducer/Countries";
import { FormControl, MenuItem, OutlinedInput, Select } from "@mui/material";
import { hospitalContactYup, handleContactNumberChange } from "../../utils/phoneValidation";
export default function AddHospitals() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [selectedImage, setSelectedImage] = useState(null);
  const { hospital, loading, error } = useSelector((state) => state.staff);
  const { Countries } = useSelector((state) => state.Countries);
  useEffect(() => {
    dispatch(GetAllCountries2());
  }, []);
  const basicSchema = Yup.object().shape({
    hospitalName: Yup.string()
      .required("Name is required")
      .min(2, "Name must be at least 2 characters")
      .max(50, "Name cannot exceed 50 characters"),
    location: Yup.string().required("Location is Required"),
    country: Yup.string().required("country is Required"),
    hospitalCode: Yup.string()
      .required("Hospital code is  Required"),
    contact: hospitalContactYup(true),
    hospitalImage: Yup.mixed()
      .required("Image is required")
      .test("fileSize", "File size is too large (Max: 2MB)", (value) =>
        value ? value.size <= 2 * 1024 * 1024 : true
      )
      .test("fileType", "Unsupported file format", (value) =>
        value
          ? ["image/jpeg", "image/png", "application/pdf"].includes(value.type)
          : true
      ),
  });
  return (
    <>
      <div className="page-wrapper">
        <div className="content">
          <div className="row">
            <div className="col-md-12">
              <h4 className="page-title">
                <span>
                  <i
                    class="fi fi-sr-angle-double-small-left"
                    onClick={() => {
                      window.history.back();
                    }}
                    style={{ cursor: "pointer" }}
                  ></i>
                </span>
                New Hospital
              </h4>
            </div>
          </div>
          <div className="main_content">
            <Formik
              initialValues={{
                hospitalName: "",
                location: "",
                hospitalCode: "",
                contact: "",
                country: "",
                hospitalImage: null,
              }}
              validationSchema={basicSchema}
              onSubmit={async (values, { setSubmitting }) => {
                try {
                  const result = await dispatch(
                    AddHospitalData(values)
                  ).unwrap();
                  Swal.fire("Hospital added successfully!", "", "success");
                  navigate("/Admin/Hospitals");
                } catch (err) {
                  console.log(err);
                  Swal.fire(
                    "Error!",
                    err?.message || "An error occurred",
                    "error"
                  );
                }
                setSubmitting(false);
              }}
            >
              {({ isSubmitting, setFieldValue }) => (
                <Form>
                  <div className="row">
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Hospital Name<span className="text-danger">*</span>
                        </label>
                        <Field
                          className="form-control"
                          type="text"
                          name="hospitalName"
                        />
                        <ErrorMessage
                          name="hospitalName"
                          component="div"
                          style={{ color: "red" }}
                        />
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Location<span className="text-danger">*</span>
                        </label>
                        <Field
                          className="form-control"
                          type="text"
                          name="location"
                        />
                        <ErrorMessage
                          name="location"
                          component="div"
                          style={{ color: "red" }}
                        />
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Hospital Code<span className="text-danger">*</span>
                        </label>
                        <Field
                          className="form-control"
                          type="text"
                          name="hospitalCode"
                        />
                        <ErrorMessage
                          name="hospitalCode"
                          component="div"
                          style={{ color: "red" }}
                        />
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Contact<span className="text-danger">*</span>{" "}
                        </label>
                        <Field
                          className="form-control"
                          type="text"
                          name="contact"
                          onChange={(e) =>
                            handleContactNumberChange(
                              e,
                              setFieldValue,
                              "contact",
                            )
                          }
                        />
                        <ErrorMessage
                          name="contact"
                          component="div"
                          style={{ color: "red" }}
                        />
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Country<span className="text-danger">*</span>
                        </label>
                        <Field name="country">
                          {({ field, form }) => (
                            <>
                              <FormControl fullWidth size="small">
                                <Select
                                  value={field.value}
                                  onChange={(e) =>
                                    form.setFieldValue(
                                      "country",
                                      e.target.value
                                    )
                                  }
                                  input={
                                    <OutlinedInput placeholder="Select Country" />
                                  }
                                  displayEmpty
                                  sx={{ height: 40 }}
                                  className="select-country form-control"
                                  MenuProps={{
                                    PaperProps: {
                                      style: { maxHeight: 200 },
                                    },
                                  }}
                                >
                                  <MenuItem value="">
                                    <em>Select Country</em>
                                  </MenuItem>
                                  {Countries && Countries.length > 0 ? (
                                    Countries.map((con, idx) => (
                                      <MenuItem key={idx} value={con.name}>
                                        {con.name}
                                      </MenuItem>
                                    ))
                                  ) : (
                                    <MenuItem disabled>
                                      No countries available
                                    </MenuItem>
                                  )}
                                </Select>
                              </FormControl>
                              <ErrorMessage
                                name="country"
                                component="div"
                                style={{ color: "red" }}
                              />
                            </>
                          )}
                        </Field>
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Hospital Image<span className="text-danger">*</span>
                        </label>
                        <div className="profile-upload">
                          <div className="upload-img">
                            {selectedImage ? (
                              <img
                                alt="preview"
                                src={URL.createObjectURL(selectedImage)}
                              />
                            ) : (
                              <img
                                alt="default avatar"
                                src="https://thumbs.dreamstime.com/b/hospital-ambulances-took-injured-to-70641786.jpg?w=992"
                                onError={(e) => {
                                  e.target.src =
                                    "https://via.placeholder.com/150";
                                }}
                              />
                            )}
                          </div>
                          <div className="upload-input">
                            <input
                              type="file"
                              className="form-control"
                              onChange={(event) => {
                                setFieldValue(
                                  "hospitalImage",
                                  event.target.files[0]
                                );
                                setSelectedImage(event.target.files[0]);
                              }}
                            />
                            <ErrorMessage
                              name="hospitalImage"
                              component="div"
                              style={{ color: "red" }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="">
                    <button
                      className="submit-btn"
                      type="submit"
                      disabled={isSubmitting || loading}
                    >
                      {isSubmitting || loading ? "Submitting..." : "Submit"}
                    </button>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      </div>
    </>
  );
}
