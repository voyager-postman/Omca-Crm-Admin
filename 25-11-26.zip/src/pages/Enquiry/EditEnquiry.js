import React, { useState, useEffect, useRef } from "react";
import { EditEnquiryType, GetAllEnquiry } from "../../reducer/EnquirySlice";
import { GetAllCountries, GetAllCountries2 } from "../../reducer/Countries";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { Formik, Field, ErrorMessage, Form } from "formik";
import * as Yup from "yup";
import CountryCodeSelect from "./CountryCodeSelect";
import { FormControl, MenuItem, OutlinedInput, Select } from "@mui/material";
import {
  AdminBaseUrl,
  baseu11,
  baseurl,
  image,
  imageUrl,
  resolveCrmImageUrl,
} from "../../Basurl/Baseurl";
import { Autocomplete, TextField } from "@mui/material";
import avtar from "../../img/avtarImg.jpg";
import axios from "axios";
import { GetAllTreatment } from "../../reducer/TreatmentSlice";
import { fetchReferrals } from "../../services/referralApi";
import { fetchInsurances } from "../../services/insuranceApi";
import { markRecordRead } from "../../services/unreadApi";
import { getDocumentDisplayName } from "../../services/enquiryReportsApi";
import ReferralCreateModal from "./ReferralCreateModal";
import InsuranceCreateModal from "./InsuranceCreateModal";
import {
  contactNumberYup,
  optionalContactNumberYup,
  contactNumberDigitsRegex,
  handleContactNumberChange,
} from "../../utils/phoneValidation";
const getFileType = (file) => {
  const ext = file.split(".").pop().toLowerCase();
  if (["jpg", "jpeg", "png", "webp"].includes(ext)) return "image";
  if (ext === "pdf") return "pdf";
  if (["doc", "docx"].includes(ext)) return "word";
  if (["xls", "xlsx"].includes(ext)) return "excel";
  return "other";
};
const normalizeReviewComments = (comments = []) =>
  comments.map((comment) => ({
    ...comment,
    Notes: comment.Notes ?? comment.comment ?? comment.notes ?? "",
    createdAt: comment.createdAt || comment.created_at,
    Date: comment.Date || comment.created_at || comment.date,
  }));

const normalizeReviewItem = (item) => ({
  ...item,
  _id: item._id || item.id,
  createdAt: item.createdAt || item.created_at,
  Recommendations: item.Recommendations ?? item.recommendations,
  comments: normalizeReviewComments(item.comments),
});

const getDoctorReviews = (row) => {
  if (!row || typeof row !== "object") return [];

  const review = row.doctorReview ?? row.doctor_review;
  if (Array.isArray(review)) {
    return review.filter(Boolean).map(normalizeReviewItem);
  }
  if (review && typeof review === "object") {
    return [normalizeReviewItem(review)];
  }

  if (
    row.review_notes ||
    row.Recommendations ||
    row.recommendations ||
    row.images?.length
  ) {
    return [
      normalizeReviewItem({
        enquiryId: row.enquiryId,
        title: row.title || row.review_title || "",
        review_notes: row.review_notes,
        Recommendations: row.Recommendations ?? row.recommendations,
        images: row.images || row.review_images || [],
        comments: row.comments || [],
        created_at: row.created_at,
        createdAt: row.createdAt,
      }),
    ];
  }

  return [];
};
const normalizeTreatingIn = (value) => {
  if (!value) return [];
  if (Array.isArray(value)) return value.filter(Boolean).map(String);
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) return parsed.filter(Boolean).map(String);
    } catch (_) {
      /* not JSON */
    }
    if (value.includes(",")) {
      return value
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
    }
    return [value];
  }
  return [];
};

const getEnquiryDocuments = (data) => {
  if (!data || typeof data !== "object") return [];
  const candidates = [
    data.documents,
    data.medical_reports,
    data.medicalReports,
    data.medical_documents,
    data.reports,
  ];
  for (const value of candidates) {
    if (Array.isArray(value) && value.length > 0) {
      return value.filter(Boolean);
    }
  }
  return [];
};

const getDocumentPath = (file) => {
  if (!file) return "";
  if (typeof file === "string") return file;
  return file.path || file.url || file.filename || file.name || "";
};

const normalizeEnquiryDetail = (data) => {
  if (!data || typeof data !== "object") return data;
  return {
    ...data,
    emergency_contact:
      data.emergency_contact || data.emergency_contact_no || data.phone || "",
    phoneCode: data.phoneCode || data.dial_code || "",
    country: data.country || "",
    treatingIn: normalizeTreatingIn(
      data.treatingIn || data.treating_in_country,
    ),
    Referral_Name:
      data.Referral_Name || data.referral_name || data.referral || "",
    referral_id: data.referral_id || data.referralId || "",
    Insurance_Name:
      data.Insurance_Name || data.insurance_name || data.insurance || "",
    insurance_id: data.insurance_id || data.insuranceId || "",
    documents: getEnquiryDocuments(data),
  };
};
const getFileUrl = (file) => {
  if (!file) return "";
  return typeof file === "string" && file.startsWith("http")
    ? file
    : `${imageUrl}${file}`;
};
const formatReviewDate = (item) => {
  const dateValue =
    item?.createdAt ||
    item?.created_at ||
    item?.Date ||
    item?.date ||
    item?.updatedAt ||
    item?.updated_at;
  if (!dateValue) return "-";
  const parsed = new Date(dateValue);
  return Number.isNaN(parsed.getTime())
    ? "-"
    : parsed.toLocaleDateString("en-GB");
};
export default function EditEnquiry() {
  const dispatch = useDispatch();
  const formikRef = useRef(null);
  const MAX_FILE_SIZE = 2 * 1024 * 1024;
  const location = useLocation();
  const navigate = useNavigate();
  const userRole = (localStorage.getItem("Role") || "").toUpperCase();
  const isReferralUser = userRole === "REFERRAL";
  const myReferralId = isReferralUser ? (localStorage.getItem("referral_id") || "") : "";
  const myName = localStorage.getItem("name") || "Referral Partner";
  const [referralsList, setReferralsList] = useState([]);
  const [showReferralModal, setShowReferralModal] = useState(false);
  const isInsuranceUserRole = userRole === "INSURANCE";
  const myInsuranceId = isInsuranceUserRole ? (localStorage.getItem("insurance_id") || "") : "";
  const myInsName = localStorage.getItem("name") || "Insurance Partner";
  const [insurancesList, setInsurancesList] = useState([]);
  const [showInsuranceModal, setShowInsuranceModal] = useState(false);
  const { Enquiry, loading } = useSelector((state) => state.Enquiry);
  const [previewImage, setPreviewImage] = useState(null);
  const { Treatment, error } = useSelector((state) => state.Treatment);
  const { Countries } = useSelector((state) => state.Countries);
  const [editenquiry, setEnquiry] = useState("");

  // Load existing referral partners
  useEffect(() => {
    const loadReferrals = async () => {
      try {
        const res = await fetchReferrals({ limit: 200, status: 1 });
        if (res && res.success && Array.isArray(res.referrals)) {
          setReferralsList(res.referrals);
        }
      } catch (err) {
        console.warn("Failed to load referrals list in EditEnquiry:", err);
      }
    };
    loadReferrals();
  }, []);

  // Load existing insurance partners
  useEffect(() => {
    const loadInsurances = async () => {
      try {
        const res = await fetchInsurances({ limit: 200, status: 1 });
        if (res && res.success && Array.isArray(res.insurances)) {
          setInsurancesList(res.insurances);
        }
      } catch (err) {
        console.warn("Failed to load insurances list in EditEnquiry:", err);
      }
    };
    loadInsurances();
  }, []);
  useEffect(() => {
    const enquiryId = location.state?.enquiryId;
    if (enquiryId) markRecordRead("enquiries", enquiryId);
  }, [location.state?.enquiryId]);
  const fetchEnquiryDetail = async () => {
    if (!location.state?.enquiryId) return;
    try {
      const response = await axios.get(
        `${baseurl}get_Enq/${location.state.enquiryId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        },
      );
      if (response.data?.success && response.data?.detail) {
        setEnquiry(normalizeEnquiryDetail(response.data.detail));
      }
    } catch (error) {
      console.error("Error fetching enquiry detail:", error);
    }
  };
  useEffect(() => {
    dispatch(GetAllCountries2());
    dispatch(GetAllEnquiry());
    dispatch(GetAllTreatment());
  }, [dispatch]);
  useEffect(() => {
    if (location.state?.enquiryId) {
      fetchEnquiryDetail();
    }
  }, [location.state?.enquiryId]);
  useEffect(() => {
    if (location.state?.enquiryId && Enquiry.length > 0 && !editenquiry) {
      const selectedUser = Enquiry.find(
        (item) => item.enquiryId === location.state.enquiryId,
      );
      if (selectedUser) {
        setEnquiry(normalizeEnquiryDetail(selectedUser));
      }
    }
  }, [location.state?.enquiryId, Enquiry, editenquiry]);
  const noOnlySpaces = (fieldName) =>
    Yup.string()
      .transform((value) => value?.trim())
      .test(
        "not-only-spaces",
        `${fieldName} cannot be empty or only spaces`,
        (value) => value && value.trim().length > 0,
      );
  const basicSchema = Yup.object().shape({
    name: noOnlySpaces("Name")
      .min(2, "Name must be at least 2 characters")
      .max(50, "Name cannot exceed 50 characters")
      .required("Name is required"),
    email: Yup.string()
      .trim()
      .transform((value) => (value === "" ? undefined : value))
      .email("Enter valid email")
      .notRequired(),
    age: Yup.string().required("Age is required"),
    town: Yup.string().trim().notRequired(),
    address: Yup.string().trim().notRequired(),
    passport_num: Yup.string()
      .trim()
      .uppercase()
      .transform((value) => (value === "" ? undefined : value))
      .matches(
        /^[A-Z0-9]{6,15}$/,
        "Passport number must be 6–15 characters (letters & digits only)",
      )
      .notRequired(),
    gender: Yup.string()
      .oneOf(["Male", "Female", "Others"])
      .required("Gender is required"),
    country: Yup.string().required("Country is required"),
    dial_code: Yup.string().required("Country code is required"),
    treatingIn: Yup.array()
      .of(Yup.string())
      .min(1, "Treating In is required")
      .required("Treating In is required"),
    emergency_contact_no: contactNumberYup({
      required: true,
      label: "Phone number",
    }),
    patient_emergency_contact_no: optionalContactNumberYup({
      label: "Emergency contact number",
    }),
    patient_relation_no: Yup.string().when(
      "has_relation",
      (hasRelation, schema) => {
        if (hasRelation) {
          return schema
            .transform((value) => (value ? value.trim() : ""))
            .test(
              "valid-number",
              "Contact number must be 8-15 digits and cannot start with 0",
              function (value) {
                if (!value) return true;
                return contactNumberDigitsRegex(8, 15).test(value);
              },
            );
        }
        return schema.notRequired();
      },
    ),
    patient_relation: Yup.string().when("has_relation", {
      is: true,
      then: (schema) => schema.required("Attendant Relationship is required"),
      otherwise: (schema) => schema.notRequired(),
    }),
    patient_relation_name: Yup.string().when("has_relation", {
      is: true,
      then: (schema) => schema.required("Attendant Name is required"),
      otherwise: (schema) => schema.notRequired(),
    }),
    patient_relation_id: Yup.array().when("has_relation", {
      is: true,
      then: (schema) =>
        schema
          .min(1, "At least one Attendant ID Proof is required")
          .test("fileSize", "Each file must be less than 2 MB", (files) => {
            if (!Array.isArray(files)) return false;
            return files.every((file) => {
              if (typeof file === "string") return true;
              if (file instanceof File) {
                return file.size <= MAX_FILE_SIZE;
              }
              return false;
            });
          }),
      otherwise: (schema) => schema.notRequired(),
    }),
    patient_id_proof: Yup.array().test(
      "fileSize",
      "Each file must be less than 2 MB",
      (files) => {
        if (!files || files.length === 0) return true;
        return files.every((file) => {
          if (typeof file === "string") return true;
          return file.size <= MAX_FILE_SIZE;
        });
      },
    ),
    patient_Profile: Yup.mixed().test(
      "fileSize",
      "File size must be less than 2 MB",
      (value) => {
        if (!value) return true;
        if (typeof value === "string") return true;
        return value.size <= MAX_FILE_SIZE;
      },
    ),
  });
  useEffect(() => {
    const initTooltips = () => {
      if (!window.bootstrap) return;
      const tooltipTriggerList = document.querySelectorAll(
        '[data-bs-toggle="tooltip"]',
      );
      tooltipTriggerList.forEach((el) => {
        if (!el._tooltip) {
          el._tooltip = new window.bootstrap.Tooltip(el, {
            placement: el.getAttribute("data-bs-placement") || "top",
            trigger: "hover focus",
          });
        }
      });
    };
    setTimeout(initTooltips, 300);
  });
  const handleCreateTreatment = async () => {
    const { value: treatmentName } = await Swal.fire({
      title: "Add Treatment",
      input: "text",
      inputLabel: "Treatment Name",
      inputPlaceholder: "Enter treatment name",
      showCancelButton: true,
      confirmButtonText: "Add",
      inputValidator: (value) => {
        if (!value) {
          return "Treatment name is required";
        }
      },
    });
    if (treatmentName) {
      const payload = { name: treatmentName };
      try {
        const response = await axios.post(
          `${AdminBaseUrl}treatment/add`,
          payload,
        );
        const data = await response.json();
        if (response.ok) {
          dispatch(GetAllTreatment());
          Swal.fire(
            "Success",
            data.message || "Treatment created successfully",
            "success",
          );
        } else {
          Swal.fire(
            "Error",
            data.message || "Failed to create treatment",
            "error",
          );
        }
      } catch (error) {
        console.log(error);
        Swal.fire(
          "Error",
          error?.response?.data?.message ||
            error.message ||
            "Something went wrong",
          "error",
        );
      }
    }
  };
  const doctorReviews = getDoctorReviews(editenquiry);
  // const renderReviewComments = (comments) => {
  //   if (!comments || comments.length === 0) {
  //     return <p className="text-muted mb-0">No comments available</p>;
  //   }
  //   return comments.map((comment, index) => (
  //     <div className="col-md-12" key={comment._id || index}>
  //       <div className="card customstylecard">
  //         <div className="card-body">
  //           <div className="note-view">
  //             <h6>{comment.user_type} Note</h6>
  //           </div>
  //           <div className="experience-box">
  //             <ul className="experience-list">
  //               <li className="mb-0">
  //                 <div className="experience-user">
  //                   <div className="before-circle"></div>
  //                 </div>
  //                 <div className="experience-content">
  //                   <div className="timeline-content">
  //                     <a href="#/" className="name">
  //                       {comment.Notes}
  //                     </a>
  //                     {comment.images && comment.images.length > 0 && (
  //                       <div className="">
  //                         {comment.images.map((img, imgIndex) => (
  //                           <button
  //                             key={imgIndex}
  //                             type="button"
  //                             className="viewbtn me-2"
  //                             onClick={() =>
  //                               window.open(getFileUrl(img), "_blank")
  //                             }
  //                           >
  //                             View {imgIndex + 1}
  //                           </button>
  //                         ))}
  //                       </div>
  //                     )}
  //                     <div>Date - {formatReviewDate(comment)}</div>
  //                   </div>
  //                 </div>
  //               </li>
  //             </ul>
  //           </div>
  //         </div>
  //       </div>
  //     </div>
  //   ));
  // };
  const renderReviewComments = (comments) => {
    if (!comments || comments.length === 0) {
      return <p className="text-muted mb-0">No comments available</p>;
    }

    const accordionId = `commentsAccordion-${comments.length}`;

    return (
      <div className="col-md-12">
        <div className="accordion" id={accordionId}>
          <div className="accordion-item border-0">
            <h2
              className="accordion-header"
              id={`commentsHeading-${comments.length}`}
            >
              <button
                className="accordion-button customstylecard collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target={`#commentsCollapse-${comments.length}`}
                aria-expanded="false"
                aria-controls={`commentsCollapse-${comments.length}`}
              >
                <span>Comments</span>
              </button>
            </h2>

            <div
              id={`commentsCollapse-${comments.length}`}
              className="accordion-collapse collapse"
              aria-labelledby={`commentsHeading-${comments.length}`}
              data-bs-parent={`#${accordionId}`}
            >
              <div className="accordion-body p-0 pt-3">
                <div className="row gy-3">
                  {comments.map((comment, index) => (
                    <div className="col-md-12" key={comment._id || index}>
                      <div className="card customstylecard">
                        <div className="card-body">
                          <div className="note-view">
                            <h6>{comment.user_type} Note</h6>
                          </div>

                          <div className="experience-box">
                            <ul className="experience-list">
                              <li className="mb-0">
                                <div className="experience-user">
                                  <div className="before-circle"></div>
                                </div>

                                <div className="experience-content">
                                  <div className="timeline-content">
                                    <a href="#/" className="name">
                                      {comment.Notes}
                                    </a>

                                    {comment.images &&
                                      comment.images.length > 0 && (
                                        <div>
                                          {comment.images.map(
                                            (img, imgIndex) => (
                                              <button
                                                key={imgIndex}
                                                type="button"
                                                className="viewbtn me-2"
                                                onClick={() =>
                                                  window.open(
                                                    getFileUrl(img),
                                                    "_blank",
                                                  )
                                                }
                                              >
                                                View {imgIndex + 1}
                                              </button>
                                            ),
                                          )}
                                        </div>
                                      )}

                                    <div>
                                      Date - {formatReviewDate(comment)}
                                    </div>
                                  </div>
                                </div>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
  const handleDeletePatientIdProof = (index) => {
    Swal.fire({
      title: "Delete this image?",
      text: "This action cannot be undone",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete",
    }).then(async (res) => {
      if (res.isConfirmed) {
        try {
          await axios.delete(`${baseurl}deletePatientIdProofByIndex`, {
            data: {
              enquiryId: editenquiry.enquiryId,
              index,
            },
          });
          setEnquiry((prev) => ({
            ...prev,
            patient_id_proof: prev.patient_id_proof.filter(
              (_, i) => i !== index,
            ),
          }));
          Swal.fire("Deleted!", "Image removed successfully.", "success");
        } catch (err) {
          Swal.fire("Error", "Unable to delete image", "error");
        }
      }
    });
  };
  const handleDeleteEnquiryDocument = (index) => {
    Swal.fire({
      title: "Delete this document?",
      text: "This will remove the medical report from this enquiry",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete",
    }).then(async (res) => {
      if (!res.isConfirmed) return;
      const currentDocs = getEnquiryDocuments(editenquiry);
      const file = currentDocs[index];
      const path = getDocumentPath(file);
      try {
        await axios.delete(`${baseurl}deleteEnquiryDocumentByIndex`, {
          data: {
            enquiryId: editenquiry.enquiryId,
            index,
            document: path,
          },
        });
      } catch (err) {
        console.warn("Document delete API not available yet:", err);
      }
      setEnquiry((prev) => ({
        ...prev,
        documents: getEnquiryDocuments(prev).filter((_, i) => i !== index),
      }));
      Swal.fire("Deleted!", "Document removed from this form.", "success");
    });
  };
  const handleDeleteAttendantIdProof = async (index) => {
    Swal.fire({
      title: "Delete this image?",
      text: "This action cannot be undone",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete",
    }).then(async (res) => {
      if (res.isConfirmed) {
        try {
          await axios.delete(`${baseurl}deletePatientRelationImageByIndex`, {
            data: {
              enquiryId: editenquiry.enquiryId,
              index,
            },
          });
          setEnquiry((prev) => ({
            ...prev,
            patient_relation_id: prev.patient_relation_id.filter(
              (_, i) => i !== index,
            ),
          }));
          Swal.fire("Deleted!", "Image removed successfully.", "success");
        } catch (err) {
          Swal.fire("Error", "Unable to delete image", "error");
        }
      }
    });
  };
  return (
    <div className="page-wrapper">
      <div className="content">
        <div className="row gx-3">
          <div className="col-md-12">
            <div className="topmainhd">
              <h6>
                <i
                  class="fa-solid fa-arrow-left-long me-2"
                  onClick={() => window.history.back()}
                ></i>
                Edit Enquiry
              </h6>
            </div>
          </div>
          <div className="col-md-12">
            <Formik
              innerRef={formikRef}
              enableReinitialize
              initialValues={{
                name: editenquiry?.name || "",
                age: editenquiry?.age || "",
                town: editenquiry?.town || "",
                email: editenquiry?.email || "",
                gender: editenquiry?.gender || "",
                dial_code:
                  editenquiry?.phoneCode ||
                  editenquiry?.dial_code ||
                  Countries.find((c) => c.name === editenquiry?.country)
                    ?.dial_code ||
                  "",
                patient_emergency_dial_code:
                  editenquiry?.patient_emergency_dial_code ||
                  editenquiry?.emergency_dial_code ||
                  editenquiry?.phoneCode ||
                  editenquiry?.dial_code ||
                  "",
                patient_relation_dial_code:
                  editenquiry?.patient_relation_dial_code ||
                  editenquiry?.phoneCode ||
                  editenquiry?.dial_code ||
                  "",
                discussion_notes: editenquiry?.discussion_notes || [],
                has_relation: !!(
                  editenquiry?.patient_relation_name ||
                  editenquiry?.patient_relation ||
                  editenquiry?.patient_relation_no
                ),
                emergency_contact_no:
                  editenquiry?.emergency_contact ||
                  editenquiry?.emergency_contact_no ||
                  editenquiry?.phone ||
                  "",
                patient_relation_name: editenquiry?.patient_relation_name || "",
                country: editenquiry?.country || "",
                treatingIn: normalizeTreatingIn(editenquiry?.treatingIn),
                disease_name: editenquiry?.disease_name || "",
                address: editenquiry?.address || "",
                patient_emergency_contact_no:
                  editenquiry?.patient_emergency_contact_no || "",
                patient_relation: editenquiry?.patient_relation || "",
                Referral_Name: editenquiry?.Referral_Name || "",
                referral_id: editenquiry?.referral_id || "",
                Insurance_Name: editenquiry?.Insurance_Name || editenquiry?.insurance_name || "",
                insurance_id: editenquiry?.insurance_id || editenquiry?.insuranceId || "",
                passport_num: editenquiry?.passport_num || "",
                patient_relation_no: editenquiry?.patient_relation_no || "",
                disease_id: editenquiry?.disease_id || "",
                patient_relation_address:
                  editenquiry?.patient_relation_address || "",
                patient_relation_id: editenquiry?.patient_relation_id || [],
                patient_id_proof: editenquiry?.patient_id_proof || [],
                patient_Profile: editenquiry?.patient_Profile || "",
                documents: [],
                doctorReviewNotes:
                  getDoctorReviews(editenquiry)[0]?.review_notes || "",
                doctorReviewRecommendations:
                  getDoctorReviews(editenquiry)[0]?.Recommendations ||
                  getDoctorReviews(editenquiry)[0]?.recommendations ||
                  "",
              }}
              validationSchema={basicSchema}
              onSubmit={async (values, { setSubmitting }) => {
                const formData = new FormData();
                for (const key in values) {
                  if (
                    key !== "patient_id_proof" &&
                    key !== "patient_Profile" &&
                    key !== "patient_relation_id" &&
                    key !== "discussion_notes" &&
                    key !== "treatingIn" &&
                    key !== "documents"
                  ) {
                    formData.append(key, values[key]);
                  }
                }
                if (values.dial_code) {
                  formData.append("phoneCode", values.dial_code);
                }
                if (values.patient_emergency_dial_code) {
                  formData.append(
                    "patient_emergency_dial_code",
                    values.patient_emergency_dial_code,
                  );
                  formData.append(
                    "emergency_dial_code",
                    values.patient_emergency_dial_code,
                  );
                } else if (values.dial_code) {
                  formData.append("patient_emergency_dial_code", values.dial_code);
                  formData.append("emergency_dial_code", values.dial_code);
                }
                formData.append(
                  "treatingIn",
                  JSON.stringify(values.treatingIn || []),
                );
                formData.append(
                  "discussionNotes",
                  JSON.stringify(values.discussion_notes),
                );
                formData.append(
                  "doctor_review_notes",
                  values.doctorReviewNotes,
                );
                formData.append(
                  "doctor_recommendations",
                  values.doctorReviewRecommendations,
                );
                if (
                  values.patient_id_proof &&
                  values.patient_id_proof.length > 0
                ) {
                  values.patient_id_proof.forEach((file) => {
                    formData.append("patient_id_proof", file);
                  });
                }
                if (values.doctor_images && values.doctor_images.length > 0) {
                  values.doctor_images.forEach((file) => {
                    if (typeof file !== "string") {
                      formData.append("doctor_review_images", file);
                    }
                  });
                }
                if (values.patient_Profile instanceof File) {
                  formData.append("patient_Profile", values.patient_Profile);
                }
                const existingDocuments = getEnquiryDocuments(editenquiry).map(
                  getDocumentPath,
                ).filter(Boolean);
                formData.append(
                  "existing_documents",
                  JSON.stringify(existingDocuments),
                );
                if (values.documents?.length > 0) {
                  values.documents.forEach((file) => {
                    if (file instanceof File) {
                      formData.append("documents", file);
                    }
                  });
                }
                if (
                  values.patient_relation_id &&
                  values.patient_relation_id.length > 0
                ) {
                  values.patient_relation_id.forEach((file) => {
                    if (typeof file !== "string") {
                      formData.append("patient_relation_id", file);
                    }
                  });
                }
                try {
                  console.log(formData);
                  await dispatch(
                    EditEnquiryType({
                      id: editenquiry.enquiryId,
                      formData,
                    }),
                  ).unwrap();
                  Swal.fire("Enquiry updated successfully!", "", "success");
                  navigate("/Admin/Inquiry");
                } catch (err) {
                  Swal.fire("Error!", err?.message || "An error occurred");
                }
                setSubmitting(false);
              }}
            >
              {({ values, isSubmitting, setFieldValue, errors, touched }) => (
                <Form encType="multipart/form-data">
                  <div className="row gx-3 gy-3">
                    <div className="col-md-12">
                      <div className="main_content">
                        <div className="row gx-3 gy-3">
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>NIC / Passport</label>
                              <Field
                                className="form-control"
                                name="passport_num"
                                type="text"
                                maxLength={15}
                              />
                              <ErrorMessage
                                name="passport_num"
                                component="div"
                                style={{ color: "red" }}
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>
                                Country<span className="text-danger">*</span>
                              </label>
                              <Field name="country">
                                {({ field, form: { setFieldValue }, meta }) => (
                                  <FormControl
                                    fullWidth
                                    size="small"
                                    error={!!meta.touched && !!meta.error}
                                  >
                                    <Select
                                      value={field.value}
                                      onChange={(e) => {
                                        setFieldValue(
                                          "country",
                                          e.target.value,
                                        );
                                      }}
                                      sx={{ height: 38 }}
                                      MenuProps={{
                                        PaperProps: {
                                          style: {
                                            maxHeight: 250,
                                          },
                                        },
                                      }}
                                    >
                                      <MenuItem value="">
                                        <em>Select Country</em>
                                      </MenuItem>
                                      {Countries.map((country, i) => (
                                        <MenuItem key={i} value={country.name}>
                                          {country.name}
                                        </MenuItem>
                                      ))}
                                    </Select>
                                    <ErrorMessage
                                      name="country"
                                      component="div"
                                      style={{ color: "red" }}
                                    />
                                  </FormControl>
                                )}
                              </Field>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>
                                {" "}
                                Phone No. / WhatsApp
                                <span className="text-danger">*</span>
                              </label>
                              <div
                                className="country-code"
                                style={{ position: "relative" }}
                              >
                                <CountryCodeSelect
                                  value={values.dial_code}
                                  onChange={(code) => {
                                    setFieldValue("dial_code", code);
                                    setFieldValue(
                                      "patient_emergency_dial_code",
                                      code,
                                    );
                                    setFieldValue(
                                      "patient_relation_dial_code",
                                      code,
                                    );
                                  }}
                                  countries={Countries}
                                  error={Boolean(
                                    errors.dial_code && touched.dial_code,
                                  )}
                                  placeholder="+Code"
                                />
                                <Field
                                  className="form-control code-in"
                                  name="emergency_contact_no"
                                  onChange={(e) =>
                                    handleContactNumberChange(
                                      e,
                                      setFieldValue,
                                      "emergency_contact_no",
                                    )
                                  }
                                />
                              </div>
                              <ErrorMessage
                                name="dial_code"
                                component="div"
                                style={{ color: "red" }}
                              />
                              <ErrorMessage
                                name="emergency_contact_no"
                                component="div"
                                style={{ color: "red" }}
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>
                                Patient's Name
                                <span className="text-danger">*</span>
                              </label>
                              <Field
                                className="form-control"
                                name="name"
                                type="text"
                              />
                              <ErrorMessage
                                name="name"
                                component="div"
                                style={{ color: "red" }}
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field gender-select">
                              <label className="gen-label">
                                Gender<span className="text-danger">*</span>
                              </label>
                              <div className="form-check-inline">
                                <label className="form-check-label">
                                  <Field
                                    type="radio"
                                    name="gender"
                                    value="Male"
                                    className="form-check-input"
                                  />{" "}
                                  Male
                                </label>
                              </div>
                              <div className="form-check-inline">
                                <label className="form-check-label">
                                  <Field
                                    type="radio"
                                    name="gender"
                                    value="Female"
                                    className="form-check-input"
                                  />{" "}
                                  Female
                                </label>
                              </div>
                              <div className="form-check-inline">
                                <label className="form-check-label">
                                  <Field
                                    type="radio"
                                    name="gender"
                                    value="Others"
                                    className="form-check-input"
                                  />{" "}
                                  Others
                                </label>
                              </div>
                            </div>
                            <ErrorMessage
                              name="gender"
                              component="div"
                              style={{ color: "red" }}
                            />
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>
                                Age<span className="text-danger">*</span>
                              </label>
                              <Field
                                className="form-control"
                                name="age"
                                type="number"
                              />
                              <ErrorMessage
                                name="age"
                                component="div"
                                style={{ color: "red" }}
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>
                                Email
                              </label>
                              <Field
                                className="form-control"
                                name="email"
                                type="email"
                              />
                              <ErrorMessage
                                name="email"
                                component="div"
                                style={{ color: "red" }}
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>
                                Town
                              </label>
                              <Field className="form-control" name="town" />
                              <ErrorMessage
                                name="town"
                                component="div"
                                style={{ color: "red" }}
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>
                                Address
                              </label>
                              <Field className="form-control" name="address" />
                              <ErrorMessage
                                name="address"
                                component="div"
                                style={{ color: "red" }}
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>Emergency Contact No</label>
                              <div
                                className="country-code"
                                style={{ position: "relative" }}
                              >
                                <CountryCodeSelect
                                  value={values.dial_code}
                                  countries={Countries}
                                  disabled={true}
                                  placeholder="+Code"
                                />
                                <Field
                                  className="form-control code-in"
                                  name="patient_emergency_contact_no"
                                  onChange={(e) =>
                                    handleContactNumberChange(
                                      e,
                                      setFieldValue,
                                      "patient_emergency_contact_no",
                                    )
                                  }
                                />
                              </div>
                              <ErrorMessage
                                name="patient_emergency_contact_no"
                                component="div"
                                style={{ color: "red" }}
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>
                                Medical Reports & Documents (Multiple){" "}
                                <span
                                  className="text-danger"
                                  data-bs-placement="right"
                                  data-bs-toggle="tooltip"
                                  title="Upload medical records, reports, scans, or images (up to 20 files, max 10MB each)"
                                >
                                  (i)
                                </span>
                              </label>
                              <input
                                className="form-control"
                                type="file"
                                name="documents"
                                multiple
                                accept="image/*,application/pdf,.doc,.docx,.xls,.xlsx"
                                onChange={(e) => {
                                  const files = Array.from(e.target.files || []);
                                  if (files.length > 20) {
                                    Swal.fire(
                                      "Too many files!",
                                      "You can upload up to 20 documents/reports",
                                      "warning",
                                    );
                                    e.target.value = "";
                                    return;
                                  }
                                  setFieldValue("documents", files);
                                }}
                              />
                              {values.documents?.length > 0 && (
                                <small className="text-success mt-1 d-block">
                                  {values.documents
                                    .map((file) => getDocumentDisplayName(file))
                                    .join(", ")}
                                </small>
                              )}
                              <div className="engpatimg enquiry-doc-list">
                                {getEnquiryDocuments(editenquiry).map(
                                  (file, index) => {
                                    const fileUrl = getFileUrl(
                                      getDocumentPath(file),
                                    );
                                    const docName = getDocumentDisplayName(
                                      file,
                                      index,
                                    );
                                    return (
                                      <div className="file-preview" key={index}>
                                        <span
                                          className="delete-icon"
                                          onClick={() =>
                                            handleDeleteEnquiryDocument(index)
                                          }
                                        >
                                          <i className="fa-solid fa-xmark"></i>
                                        </span>
                                        <button
                                          type="button"
                                          className="viewbtn viewbtn-filename"
                                          title={docName}
                                          onClick={() =>
                                            window.open(fileUrl, "_blank")
                                          }
                                        >
                                          {docName}
                                        </button>
                                      </div>
                                    );
                                  },
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>
                                Patient Id Proof
                                <span className="text-danger"></span>{" "}
                                <span
                                  className="text-danger"
                                  data-bs-placement="right"
                                  data-bs-toggle="tooltip"
                                  title="Accept only (.jpeg, .jpg, .png, .jfif, .pdf) Max size: 2 MB per file"
                                >
                                  (i)
                                </span>
                              </label>
                              <input
                                className="form-control"
                                type="file"
                                name="patient_id_proof"
                                accept="image/*,application/pdf"
                                multiple
                                onChange={(e) => {
                                  const files = Array.from(
                                    e.currentTarget.files,
                                  );
                                  setFieldValue("patient_id_proof", files);
                                }}
                              />
                              <div className="engpatimg">
                                {Array.isArray(editenquiry?.patient_id_proof) &&
                                  editenquiry.patient_id_proof.length > 0 &&
                                  editenquiry.patient_id_proof.map(
                                    (file, index) => {
                                      const type = getFileType(file);
                                      const fileUrl = `${imageUrl}${file}`;

                                      return (
                                        <div
                                          className="file-preview"
                                          key={index}
                                        >
                                          <span
                                            className="delete-icon"
                                            onClick={() =>
                                              handleDeletePatientIdProof(index)
                                            }
                                          >
                                            <i className="fa-solid fa-xmark"></i>
                                          </span>
                                          <button
                                            type="button"
                                            className="viewbtn"
                                            onClick={() =>
                                              window.open(fileUrl, "_blank")
                                            }
                                          >
                                            {type === "image" && "View"}
                                            {type === "pdf" && "View"}
                                            {type === "word" && "View"}
                                            {type === "excel" && "View"}
                                            {![
                                              "image",
                                              "pdf",
                                              "word",
                                              "excel",
                                            ].includes(type) && "View"}
                                          </button>
                                        </div>
                                      );
                                    },
                                  )}
                              </div>
                              <ErrorMessage
                                name="patient_id_proof"
                                component="div"
                                className="text-danger"
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>
                                Patient Profile
                                <span className="text-danger"></span>{" "}
                                <span
                                  className="text-danger"
                                  data-bs-placement="right"
                                  data-bs-toggle="tooltip"
                                  title="Accept only (.jpeg, .jpg, .png, .jfif, .pdf, .docx, .xlsx ) Max size: 2 MB per file"
                                >
                                  (i)
                                </span>
                              </label>
                              <input
                                className="form-control"
                                type="file"
                                name="patient_Profile"
                                accept="image/*,application/pdf"
                                onChange={(e) => {
                                  const file = e.currentTarget.files[0];

                                  if (file) {
                                    setPreviewImage(URL.createObjectURL(file));
                                    setFieldValue("patient_Profile", file);
                                  }
                                }}
                              />

                              <div className="engpatimg">
                                {previewImage ? (
                                  <button
                                    type="button"
                                    className="viewbtn"
                                    onClick={() =>
                                      window.open(previewImage, "_blank")
                                    }
                                  >
                                    View
                                  </button>
                                ) : editenquiry?.patient_Profile ? (
                                  <button
                                    type="button"
                                    className="viewbtn"
                                    onClick={() =>
                                      window.open(
                                        resolveCrmImageUrl(editenquiry.patient_Profile),
                                        "_blank",
                                      )
                                    }
                                  >
                                    View
                                  </button>
                                ) : null}
                              </div>
                              <ErrorMessage
                                name="patient_Profile"
                                component="div"
                                className="text-danger"
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              {isReferralUser ? (
                                <>
                                  <label className="mb-1">Referral Partner</label>
                                  <div
                                    className="p-2 border rounded bg-light d-flex align-items-center justify-content-between"
                                    style={{ minHeight: "38px" }}
                                  >
                                    <div>
                                      <strong className="text-success">{myName}</strong>
                                      {myReferralId && (
                                        <span className="badge bg-secondary ms-2">
                                          {myReferralId}
                                        </span>
                                      )}
                                    </div>
                                    <span className="badge bg-success">Active Partner</span>
                                  </div>
                                </>
                              ) : (
                                <>
                                  <div className="d-flex justify-content-between align-items-center mb-1">
                                    <label className="mb-0">Referral Name</label>
                                    <button
                                      type="button"
                                      className="add-button approvebtn"
                                      onClick={() => setShowReferralModal(true)}
                                    >
                                      + Add
                                    </button>
                                  </div>
                                  <Field name="Referral_Name">
                                    {({ form }) => {
                                      const selectedOption =
                                        referralsList.find(
                                          (r) =>
                                            r.name === form.values.Referral_Name ||
                                            (form.values.referral_id &&
                                              (r.referral_id === form.values.referral_id ||
                                                String(r.id) === String(form.values.referral_id)))
                                        ) ||
                                        (form.values.Referral_Name
                                          ? {
                                              name: form.values.Referral_Name,
                                              referral_id: form.values.referral_id || "",
                                            }
                                          : null);

                                      return (
                                        <Autocomplete
                                          freeSolo
                                          options={referralsList}
                                          getOptionLabel={(option) => {
                                            if (typeof option === "string") return option;
                                            if (!option) return "";
                                            const code = option.referral_id ? ` (${option.referral_id})` : "";
                                            return `${option.name || ""}${code}`;
                                          }}
                                          value={selectedOption}
                                          isOptionEqualToValue={(option, value) => {
                                            if (!value) return false;
                                            if (typeof value === "string") return option.name === value;
                                            return (
                                              option.id === value.id ||
                                              option.referral_id === value.referral_id ||
                                              option.name === value.name
                                            );
                                          }}
                                          onChange={(e, newValue) => {
                                            if (typeof newValue === "string") {
                                              form.setFieldValue("Referral_Name", newValue);
                                              form.setFieldValue("referral_id", "");
                                            } else if (newValue) {
                                              form.setFieldValue("Referral_Name", newValue.name || "");
                                              form.setFieldValue(
                                                "referral_id",
                                                newValue.referral_id || newValue.id || ""
                                              );
                                            } else {
                                              form.setFieldValue("Referral_Name", "");
                                              form.setFieldValue("referral_id", "");
                                            }
                                          }}
                                          onInputChange={(e, newInputValue, reason) => {
                                            if (reason === "input") {
                                              form.setFieldValue("Referral_Name", newInputValue);
                                            }
                                          }}
                                          renderInput={(params) => (
                                            <TextField
                                              {...params}
                                              size="small"
                                              placeholder="Select or enter referrer..."
                                              sx={{
                                                "& .MuiInputBase-root": {
                                                  height: 38,
                                                },
                                              }}
                                            />
                                          )}
                                        />
                                      );
                                    }}
                                  </Field>
                                  <ErrorMessage
                                    name="Referral_Name"
                                    component="div"
                                    style={{ color: "red" }}
                                  />
                                </>
                              )}
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              {isInsuranceUserRole ? (
                                <>
                                  <label className="mb-1">Insurance Partner</label>
                                  <div
                                    className="p-2 border rounded bg-light d-flex align-items-center justify-content-between"
                                    style={{ minHeight: "38px" }}
                                  >
                                    <div>
                                      <strong className="text-info">{myInsName}</strong>
                                      {myInsuranceId && (
                                        <span className="badge bg-secondary ms-2">
                                          {myInsuranceId}
                                        </span>
                                      )}
                                    </div>
                                    <span className="badge bg-info">Active Partner</span>
                                  </div>
                                </>
                              ) : (
                                <>
                                  <div className="d-flex justify-content-between align-items-center mb-1">
                                    <label className="mb-0">
                                      Insurance Partner
                                    </label>
                                    <button
                                      type="button"
                                      className="add-button approvebtn"
                                      onClick={() => setShowInsuranceModal(true)}
                                    >
                                      + Add
                                    </button>
                                  </div>
                                  <Field name="Insurance_Name">
                                    {({ form }) => {
                                      const selectedOption =
                                        insurancesList.find(
                                          (r) =>
                                            r.name === form.values.Insurance_Name ||
                                            (form.values.insurance_id &&
                                              (r.insurance_id === form.values.insurance_id ||
                                                String(r.id) === String(form.values.insurance_id)))
                                        ) ||
                                        (form.values.Insurance_Name
                                          ? {
                                              name: form.values.Insurance_Name,
                                              insurance_id: form.values.insurance_id || "",
                                            }
                                          : null);

                                      return (
                                        <Autocomplete
                                          freeSolo
                                          options={insurancesList}
                                          getOptionLabel={(option) => {
                                            if (typeof option === "string") return option;
                                            if (!option) return "";
                                            const code = option.insurance_id ? ` (${option.insurance_id})` : "";
                                            return `${option.name || ""}${code}`;
                                          }}
                                          value={selectedOption}
                                          isOptionEqualToValue={(option, value) => {
                                            if (!value) return false;
                                            if (typeof value === "string") return option.name === value;
                                            return (
                                              option.id === value.id ||
                                              option.insurance_id === value.insurance_id ||
                                              option.name === value.name
                                            );
                                          }}
                                          onChange={(e, newValue) => {
                                            if (typeof newValue === "string") {
                                              form.setFieldValue("Insurance_Name", newValue);
                                              form.setFieldValue("insurance_id", "");
                                            } else if (newValue) {
                                              form.setFieldValue("Insurance_Name", newValue.name || "");
                                              form.setFieldValue(
                                                "insurance_id",
                                                newValue.insurance_id || newValue.id || ""
                                              );
                                            } else {
                                              form.setFieldValue("Insurance_Name", "");
                                              form.setFieldValue("insurance_id", "");
                                            }
                                          }}
                                          onInputChange={(e, newInputValue, reason) => {
                                            if (reason === "input") {
                                              form.setFieldValue("Insurance_Name", newInputValue);
                                            }
                                          }}
                                          renderInput={(params) => (
                                            <TextField
                                              {...params}
                                              size="small"
                                              placeholder="Select or enter insurance partner..."
                                              sx={{
                                                "& .MuiInputBase-root": {
                                                  height: 38,
                                                },
                                              }}
                                            />
                                          )}
                                        />
                                      );
                                    }}
                                  </Field>
                                  <ErrorMessage
                                    name="Insurance_Name"
                                    component="div"
                                    style={{ color: "red" }}
                                  />
                                </>
                              )}
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <div className="d-flex justify-content-between align-items-center mb-1">
                                <label className="mb-0">Treatment Name</label>

                                <button
                                  type="button"
                                  className="add-button approvebtn"
                                  onClick={handleCreateTreatment}
                                >
                                  + Add
                                </button>
                              </div>
                              <Autocomplete
                                options={Treatment || []}
                                getOptionLabel={(option) => option.name || ""}
                                value={
                                  Treatment?.find(
                                    (item) => item.name === values.disease_name,
                                  ) || null
                                }
                                onChange={(e, value) => {
                                  setFieldValue(
                                    "disease_name",
                                    value?.name || "",
                                  );
                                  setFieldValue(
                                    "treatment_course_id",
                                    value?.course_id || null,
                                  );
                                  setFieldValue(
                                    "disease_id",
                                    value?.id || null,
                                  );
                                }}
                                ListboxProps={{
                                  style: {
                                    maxHeight: 250,
                                    overflow: "auto",
                                  },
                                }}
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    placeholder="Select Treatment"
                                    error={Boolean(
                                      values.disease_name === "" &&
                                      basicSchema?.fields?.disease_name,
                                    )}
                                  />
                                )}
                                sx={{
                                  height: 38,
                                  "& .MuiOutlinedInput-root": {
                                    padding: "0px",
                                    "&:hover fieldset": {
                                      borderColor: "#ced4da",
                                    },
                                  },
                                }}
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="set-field">
                              <label>
                                Treating In Country
                                <span className="text-danger">*</span>
                              </label>
                              <Field name="treatingIn">
                                {({ form, meta }) => {
                                  const selectedCountries = (
                                    Countries || []
                                  ).filter((c) =>
                                    (form.values.treatingIn || []).includes(
                                      c.name,
                                    ),
                                  );
                                  return (
                                    <Autocomplete
                                      multiple
                                      options={Countries || []}
                                      value={selectedCountries}
                                      getOptionLabel={(option) =>
                                        option?.name || ""
                                      }
                                      isOptionEqualToValue={(option, value) =>
                                        option.name === value?.name
                                      }
                                      onChange={(e, newValue) => {
                                        form.setFieldValue(
                                          "treatingIn",
                                          (newValue || []).map((c) => c.name),
                                        );
                                      }}
                                      ListboxProps={{
                                        style: {
                                          maxHeight: 250,
                                          overflow: "auto",
                                        },
                                      }}
                                      renderInput={(params) => (
                                        <TextField
                                          {...params}
                                          placeholder="Select Country"
                                          size="small"
                                          error={
                                            !!meta.touched && !!meta.error
                                          }
                                          sx={{
                                            "& .MuiInputBase-root": {
                                              minHeight: 38,
                                            },
                                            "& .MuiInputBase-input": {
                                              padding: "6px 12px",
                                            },
                                          }}
                                        />
                                      )}
                                    />
                                  );
                                }}
                              </Field>
                              <ErrorMessage
                                name="treatingIn"
                                component="div"
                                className="text-danger"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    {values.discussion_notes?.map((note, index) => (
                      <div className="col-md-12">
                        <div className="main_content">
                          <div className="comnthis">
                            <h6>Notes</h6>
                          </div>
                          <div className="set-field" key={index}>
                            <div className="noteadv">
                              <label>Note-{index + 1}</label>
                              <h6>
                                Date -{" "}
                                {new Date(note.date).toLocaleDateString(
                                  "en-GB",
                                )}
                              </h6>
                            </div>
                            <Field
                              as="textarea"
                              name={`discussion_notes.${index}.note`}
                              className="form-control"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                    {doctorReviews.length > 0 && (
                      <div className="col-md-12">
                        <div className="main_content">
                          <div className="row gx-3 gy-3">
                            <div className="col-md-12">
                              <div className="comnthis">
                                <h6>Doctor Review</h6>
                              </div>
                              {doctorReviews.map((review, reviewIndex) => (
                                <div
                                  className="forborder mb-3"
                                  key={review._id || reviewIndex}
                                >
                                  <div className="row gx-3 gy-3">
                                    <div className="col-md-2">
                                      <div className="">
                                        <h6>Date</h6>
                                        <p>{formatReviewDate(review)}</p>
                                      </div>
                                    </div>
                                    <div className="col-md-2">
                                      <div className="">
                                        <h6>Subject</h6>
                                        <p>
                                          {review?.title ||
                                            review?.Title ||
                                            "-"}
                                        </p>
                                      </div>
                                    </div>
                                    <div className="col-md-2">
                                      <div className="">
                                        <h6>Notes</h6>
                                        <p>{review?.review_notes || "-"}</p>
                                      </div>
                                    </div>
                                    <div className="col-md-3">
                                      <div className="">
                                        <h6>Recommendation</h6>
                                        <p>
                                          {review?.Recommendations ||
                                            review?.recommendations ||
                                            "-"}
                                        </p>
                                      </div>
                                    </div>
                                    <div className="col-md-3">
                                      <div className="">
                                        <h6>Documentation</h6>
                                        {review?.images?.length > 0 ? (
                                          review.images.map((img, index) => (
                                            <button
                                              key={index}
                                              type="button"
                                              className="viewbtn me-2"
                                              onClick={() =>
                                                window.open(
                                                  getFileUrl(img),
                                                  "_blank",
                                                )
                                              }
                                            >
                                              View {index + 1}
                                            </button>
                                          ))
                                        ) : (
                                          <span>-</span>
                                        )}
                                      </div>
                                    </div>
                                    <div className="col-md-12">
                                      <div className="row gy-3">
                                        {renderReviewComments(review.comments)}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                    <div className="col-md-12">
                      <div className="main_content">
                        <div className="row gx-3 gy-3">
                          <div className="col-md-12">
                            <div className="comnthis">
                              <h6>Attendant Details</h6>
                            </div>
                            <div className="form-check">
                              <Field
                                type="checkbox"
                                name="has_relation"
                                className="form-check-input"
                                id="hasRelation"
                              />
                              <label
                                className="form-check-label"
                                htmlFor="hasRelation"
                              >
                                Add Attendant
                              </label>
                            </div>
                          </div>
                          <div className="col-md-12">
                            {values.has_relation && (
                              <>
                                <div className="row gx-3 gy-3">
                                  <div className="col-md-4">
                                    <div className="set-field">
                                      <label>
                                        Attendant Full Name
                                        <span className="text-danger">*</span>
                                      </label>
                                      <Field
                                        className="form-control"
                                        name="patient_relation_name"
                                      />
                                      <ErrorMessage
                                        name="patient_relation_name"
                                        component="div"
                                        style={{ color: "red" }}
                                      />
                                    </div>
                                  </div>
                                  <div className="col-md-4">
                                    <div className="set-field">
                                      <label>
                                        Attendant Relationship With Patient
                                        <span className="text-danger">*</span>
                                      </label>
                                      <Field
                                        className="form-control"
                                        name="patient_relation"
                                      />
                                      <ErrorMessage
                                        name="patient_relation"
                                        component="div"
                                        style={{ color: "red" }}
                                      />
                                    </div>
                                  </div>
                                  <div className="col-md-4">
                                    <div className="set-field">
                                      <label>Attendant Contact Number</label>
                                      <div
                                        className="country-code"
                                        style={{ position: "relative" }}
                                      >
                                        <CountryCodeSelect
                                          value={values.dial_code}
                                          countries={Countries}
                                          disabled={true}
                                          placeholder="+Code"
                                        />
                                        <Field
                                          className="form-control code-in"
                                          name="patient_relation_no"
                                          onChange={(e) =>
                                            handleContactNumberChange(
                                              e,
                                              setFieldValue,
                                              "patient_relation_no",
                                            )
                                          }
                                        />
                                      </div>
                                      <ErrorMessage
                                        name="patient_relation_no"
                                        component="div"
                                        className="text-danger"
                                      />
                                    </div>
                                  </div>
                                  <div className="col-md-4">
                                    <div className="set-field">
                                      <label>
                                        Attendant ID Proof
                                        <span
                                          className="text-danger"
                                          data-bs-toggle="tooltip"
                                          title="Accept only (.jpeg, .jpg, .png, .jfif, .pdf)
                                            Max size: 2 MB per file"
                                          data-bs-placement="right"
                                        >
                                          {" "}
                                          (i)
                                        </span>
                                      </label>
                                      <input
                                        className="form-control"
                                        type="file"
                                        name="patient_relation_id"
                                        accept="image/*,application/pdf"
                                        multiple
                                        onChange={(e) => {
                                          const files = Array.from(
                                            e.currentTarget.files,
                                          );
                                          setFieldValue(
                                            "patient_relation_id",
                                            files,
                                          );
                                        }}
                                      />
                                      <div className="engpatimg">
                                        {Array.isArray(
                                          editenquiry.patient_relation_id,
                                        ) &&
                                        editenquiry.patient_relation_id.length >
                                          0
                                          ? editenquiry.patient_relation_id.map(
                                              (file, index) => {
                                                const fileUrl = `${imageUrl}${file}`;
                                                return (
                                                  <div className="">
                                                    <div
                                                      className="file-preview"
                                                      key={index}
                                                    >
                                                      <span
                                                        className="delete-icon"
                                                        onClick={() =>
                                                          handleDeleteAttendantIdProof(
                                                            index,
                                                          )
                                                        }
                                                      >
                                                        <i class="fa-solid fa-xmark"></i>
                                                      </span>
                                                      <button
                                                        type="button"
                                                        className="viewbtn"
                                                        onClick={() =>
                                                          window.open(
                                                            fileUrl,
                                                            "_blank",
                                                          )
                                                        }
                                                      >
                                                        View
                                                      </button>
                                                    </div>
                                                  </div>
                                                );
                                              },
                                            )
                                          : ""}
                                      </div>
                                      <ErrorMessage
                                        name="patient_relation_id"
                                        component="div"
                                        className="text-danger"
                                      />
                                    </div>
                                  </div>
                                  <div className="col-md-4">
                                    <div className="set-field">
                                      <label>Attendant Address</label>
                                      <Field
                                        className="form-control"
                                        name="patient_relation_address"
                                      />
                                    </div>
                                  </div>
                                </div>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-12">
                      <button
                        type="submit"
                        className="submit-btn"
                        disabled={isSubmitting || loading}
                      >
                        {loading ? "Submitting..." : "Submit"}
                      </button>
                    </div>
                  </div>
                </Form>
              )}
            </Formik>
            {/* Referral Create Modal */}
            <ReferralCreateModal
              open={showReferralModal}
              onClose={() => setShowReferralModal(false)}
              onSuccess={(newReferral) => {
                if (newReferral) {
                  setReferralsList((prev) => [newReferral, ...prev]);
                  if (formikRef.current) {
                    formikRef.current.setFieldValue(
                      "Referral_Name",
                      newReferral.name || ""
                    );
                    formikRef.current.setFieldValue(
                      "referral_id",
                      newReferral.referral_id || newReferral.id || ""
                    );
                  }
                }
              }}
            />
            {/* Insurance Create Modal */}
            <InsuranceCreateModal
              open={showInsuranceModal}
              onClose={() => setShowInsuranceModal(false)}
              onSuccess={(newInsurance) => {
                if (newInsurance) {
                  setInsurancesList((prev) => [newInsurance, ...prev]);
                  if (formikRef.current) {
                    formikRef.current.setFieldValue(
                      "Insurance_Name",
                      newInsurance.name || ""
                    );
                    formikRef.current.setFieldValue(
                      "insurance_id",
                      newInsurance.insurance_id || newInsurance.id || ""
                    );
                  }
                }
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
