
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { testForms } from "../../reducer/FormsEnquiry";
import VisibilityIcon from "@mui/icons-material/Visibility";
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, TextField, InputAdornment, IconButton, Pagination, Stack,
  Modal, Box,
  Dialog,
  DialogContent,
  FormControl,
  Select,
  MenuItem
} from "@mui/material";

import ClearIcon from "@mui/icons-material/Clear";
import axios from "axios";
import { AdminBaseUrl } from "../../Basurl/Baseurl";
import Swal from "sweetalert2";

export default function Labstests() {
  const isReferral = (localStorage.getItem("Role") || "").toUpperCase() === "REFERRAL";
  const dispatch = useDispatch();

  const { testForms: formData, loading, error } = useSelector(
    (state) => state.testForms
  );

  const [filterValue, setFilterValue] = useState("");
  const [page, setPage] = useState(0);
  const rowsPerPage = 10;

  // Popup states
  const [open, setOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

    useEffect(() => {
    if (!formData?.data) {
      dispatch(testForms());
    }
  }, [dispatch, formData?.data]);

  const medicalVisaData = formData?.data?.get_treatment_estimate || [];

  const handleFilter = (e) => {
    setFilterValue(e.target.value);
    setPage(0);
  };

  const handleClearFilter = () => {
    setFilterValue("");
    setPage(0);
  };

  const filteredData = medicalVisaData.filter((item) => {
    const search = filterValue.toLowerCase();

    return (
      item.name?.toLowerCase().includes(search) ||
      item.email?.toLowerCase().includes(search) ||
      item.phone?.toLowerCase().includes(search) ||
      item.whatsapp?.toLowerCase().includes(search) ||
      item.country?.toLowerCase().includes(search) ||
      item.treatment?.toLowerCase().includes(search) ||
      item.message?.toLowerCase().includes(search)
    );
  });


  const paginatedData = filteredData.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  // Open popup
  const handleView = (record) => {
    setSelectedRecord(record);
    setOpen(true);
  };
  const fullWidth = true;
  const maxWidth = "lg"; // xs | sm | md | lg | xl

  const handleClose = () => setOpen(false);
  /* ========= Reusable Info Item ========= */
  const InfoItem = ({ label, value }) => (
    <div className="">
      <h6>{label}</h6>
      <p>{value || "-"}</p>
    </div>
  );
  const handleChangtype = async (e, b) => {
    if (isReferral) return;
    console.log(e, b);

  const data = {
    id: b?.id,
    model: "PatientQuery",
    status: e?.value || e?.target?.value
  };

  try {
    const response = await axios.post(
      `${AdminBaseUrl}update_user_request_status`,
      data
    );
  dispatch(testForms());
    if (response?.data?.success) {
      Swal.fire("Success", "Status Updated Successfully", "success");
    }

  } catch (error) {
    console.log(error);

    Swal.fire("Error", "Something went wrong", "error");
  }
};

  return (
    <div>

      {loading && <p>Loading...</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}
      <div className="d-flex justify-content-between">
        <div>
          <h2>Treatment Estimate</h2>
        </div >
        <div>
          <div style={{ maxWidth: "300px", marginBottom: "15px" }}>
            <TextField
              label="Search"
              size="small"
              value={filterValue}
              onChange={handleFilter}
              InputLabelProps={{ shrink: true }}
              placeholder="Search..."
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    {filterValue && (
                      <IconButton onClick={handleClearFilter}>
                        <ClearIcon />
                      </IconButton>
                    )}
                  </InputAdornment>
                ),
              }}
              sx={{ width: "100%" }}
            />
          </div>
        </div>
      </div>
      {/* Search */}


      {/* Table */}
      <TableContainer component={Paper}
        style={{ overflowX: "auto" }}>
        <Table
          stickyHeader
          aria-label="sticky table"
          className="table-no-card"
        >
          <TableHead>
            <TableRow>
              <TableCell>Sr No.</TableCell>
              <TableCell> Name</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Phone</TableCell>
              <TableCell>Date</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {paginatedData.length > 0 ? (
              paginatedData.map((item, i) => (
                <TableRow key={i}>
                  <TableCell>{page * rowsPerPage + i + 1}</TableCell>
                  <TableCell>{item.name}</TableCell>
                  <TableCell>{item.email}</TableCell>
                  <TableCell>{item.phone}</TableCell>
                  <TableCell>{new Date(item.created_at).toLocaleDateString('en-GB')}</TableCell>
                       <TableCell>
                                                          <FormControl
                                                            sx={{ m: 1, minWidth: 120 }}
                                                            size="small"
                                                            className="cont-main"
                                                          >
                                                            <Select
                                                              value={item.status}
                                                              onChange={(e) => {
                                                                if (isReferral) return;
                                                                handleChangtype(e, item);
                                                              }}
                                                              disabled={isReferral}
                                                              displayEmpty
                                                              inputProps={{
                                                                "aria-label": "Without label",
                                                              }}
                                                              className="status-direct"
                                                              sx={
                                                                isReferral
                                                                  ? {
                                                                      "&.Mui-disabled": {
                                                                        cursor: "not-allowed",
                                                                        backgroundColor: "#f9f9f9",
                                                                      },
                                                                      "& .MuiSelect-select.Mui-disabled": {
                                                                        WebkitTextFillColor: "var(--bs-text-color, #333)",
                                                                        fontWeight: 600,
                                                                        cursor: "not-allowed",
                                                                      },
                                                                    }
                                                                  : {}
                                                              }
                                                            >
                                                              <MenuItem value="Pending">
                                                                Pending
                                                              </MenuItem>
                                                              <MenuItem value="In-Process">
                                                                In-Process
                                                              </MenuItem>
                                                              <MenuItem value="Closed">
                                                                Close
                                                              </MenuItem>
                                                            </Select>
                                                          </FormControl>
                                                        </TableCell>
                  <TableCell>
                    <VisibilityIcon
                      className="eye-icon"
                      style={{cursor:"pointer"}}
                      onClick={() => handleView(item)}
                    />
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} align="center">
                  No Data Found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>

        {/* Pagination */}
        <Stack spacing={2} alignItems="end" marginTop={2} padding={2}>
          <Pagination
            count={Math.ceil(filteredData.length / rowsPerPage)}
            page={page + 1}
            onChange={(event, value) => setPage(value - 1)}
            shape="rounded"
          />
        </Stack>
      </TableContainer>

      {/* Popup Modal */}
      <Dialog
        fullWidth={fullWidth}
        maxWidth={maxWidth}
        open={open} onClose={handleClose}
      >
        <div className="main-card-header">
          <div className="top-fixed-hd">
            <div className="note-hd">
              < h6>Estimate Treatment  </h6>
            </div>
            <div className="cross-icon" onClick={handleClose}>
              <i className="fa-solid fa-xmark"></i>
            </div>
          </div>
        </div>
        <DialogContent className="main-box view-table-detail">
          {selectedRecord && (
            <Box>
              <div className="row">
                {/* personal */}
                <div className="col-md-12 mb-3">
                  {/* <div className="all-hd mb-3">
                        <h6>Personal Information</h6>
                      </div> */}
                  <div className="card">
                    <div className="card-body">
                      <div className="row">
                        <div className="col-md-4">
                          <InfoItem label="Name" value={selectedRecord.name} />
                        </div>
                        <div className="col-md-4">
                          <InfoItem label="Email" value={selectedRecord.email} />
                        </div>
                        <div className="col-md-4">
                          <InfoItem label="Phone Number" value={selectedRecord.phone} />
                        </div>
                        <div className="col-md-4">
                          <InfoItem label="Date" value={new Date(selectedRecord.created_at).toLocaleDateString('en-GB')} />
                        </div>
                        <div className="col-md-4">
                          <InfoItem label="Whatsapp" value={selectedRecord.whatsapp} />
                        </div>
                        <div className="col-md-4">
                          <InfoItem label="Country" value={selectedRecord.country} />
                        </div>
                        <div className="col-md-4">
                          <InfoItem label="Treatment" value={selectedRecord.treatment} />
                        </div>
                    <div className="col-md-4">
  <h6>Image</h6>
  {selectedRecord.image ? (
    <img
      src={selectedRecord.image}
      alt="treatment"
      style={{
        width: "120px",
        height: "120px",
        objectFit: "cover",
        borderRadius: "6px",
        border: "1px solid #ddd"
      }}
    />
  ) : (
    <p>-</p>
  )}
</div>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Box>
          )}
        </DialogContent>

      </Dialog>
    </div>
  );
}
