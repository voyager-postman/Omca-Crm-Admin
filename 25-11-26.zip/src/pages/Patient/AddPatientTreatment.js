import React from "react";
import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Swal from "sweetalert2";
import { Formik, Field, ErrorMessage, Form } from "formik";
import * as Yup from "yup";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import { AddTretmentForPatient } from "../../reducer/PatientTreatmentSlice";
import { NavLink, useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { baseurl, AdminBaseUrl, baseu11 } from "../../Basurl/Baseurl";
import axios from "axios";
import { GetAllTreatment } from "../../reducer/TreatmentSlice";
import Treatments from "../Treatments/Treatments";
import {
  calculateDiscountPercentage,
  calculateFinalAmount,
} from "../../utils/discountHelpers";
import { isReferralUser } from "../../utils/authStorage";
import { saveTreatmentCommissionData } from "../../utils/treatmentCommissionHelpers";
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};
export default function AddPatientTreatment() {
  const location = useLocation();
  console.log(location?.state?.patient);
  const dispatch = useDispatch();

  const { Treatment, loading, error } = useSelector((state) => state.Treatment);
  // const [Treatment,setTreatment]=useState([])
  const [Service, setService] = useState([]);
  const [personName, setPersonName] = React.useState([]);
  useEffect(() => {
    dispatch(GetAllTreatment());
  }, [dispatch]);
  const navigate = useNavigate();
  const GetActiveService = () => {
    axios
      .get(`${baseurl}get_activeServices`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        console.log(response.data.services);
        if (response.status === 200) {
          setService(response.data.services);
        } else {
          console.error("Failed to fetch job titles:", response.data.message);
        }
      })
      .catch((error) => {
        console.error("Error fetching job titles:", error);
      });
  };

  useEffect(() => {
    if (isReferralUser()) {
      Swal.fire({
        icon: "error",
        title: "Access Denied",
        text: "Referrals cannot add or edit treatments.",
      });
      navigate("/Admin/patients");
      return;
    }
    dispatch(GetAllTreatment());
    GetActiveService();
  }, [dispatch, navigate]);
  // const Apidata = () => {
  //   axios
  //     .get(`${baseurl}get_all_treatment_courses`, {
  //       headers: {
  //         Authorization: `Bearer ${localStorage.getItem("token")}`,
  //         "Content-Type": "application/json",
  //       },
  //     })
  //     .then((response) => {
  //       console.log(response.data);
  //       if (response.status === 200) {
  //         setTreatment(response.data.treatment_courses);
  //       } else {
  //         console.error("Failed to fetch job titles:", response.data.message);
  //       }
  //     })
  //     .catch((error) => {
  //       console.error("Error fetching job titles:", error);
  //     });
  // };
  // useEffect(() => {
  //   Apidata();
  // }, []);
  // const basicSchema = Yup.object().shape({
  //   patientId: Yup.string().required("patientId is required"),
  //   treatment_course_id: Yup.string().required("Treatment course  is required"),
  //   services: Yup.array()
  //     .of(Yup.string().required("Service ID is required"))
  //     .min(1, "Select at least one service"),
  //   total_charge: Yup.string().required("Total Charge is required"),
  //   // amount_paid: Yup.string().required("Amount Paid is required"),
  //    amount_paid: Yup.number().required("Amount Paid is required").typeError("Amount Paid must be a number")
  //   .required("Amount Paid is required")            // ✅ REQUIRED
  //   .min(1, "Amount Paid must be greater than 0")   // ✅ no 0 or negative
  //   .max(
  //     Yup.ref("total_charge"),
  //     "Amount Paid cannot be greater than Total Charge"
  //   ),
  // });
  const basicSchema = Yup.object().shape({
    patientId: Yup.string().required("patientId is required"),

    treatment_course_id: Yup.string().required("Treatment course is required"),

    services: Yup.array().min(1, "Select at least one service"),

    total_charge: Yup.number()
      .typeError("Total Charge must be a number")
      .required("Total Charge is required"),
    discount_percentage: Yup.number()
      .transform((value, originalValue) =>
        originalValue === "" ? undefined : value,
      )
      .min(0, "Discount cannot be less than 0")
      .max(100, "Discount cannot be greater than 100")
      .nullable(),
    final_amount: Yup.number()
      .transform((value, originalValue) =>
        originalValue === "" ? undefined : value,
      )
      .min(0, "Final amount cannot be less than 0")
      .max(
        Yup.ref("total_charge"),
        "Final amount cannot be greater than total charge",
      )
      .nullable(),
    commission_percentage: Yup.number()
      .transform((value, originalValue) =>
        originalValue === "" ? undefined : value,
      )
      .min(0, "Commission cannot be less than 0")
      .max(100, "Commission cannot be greater than 100")
      .nullable(),
    insurance_percentage: Yup.number()
      .transform((value, originalValue) =>
        originalValue === "" ? undefined : value,
      )
      .min(0, "Insurance percentage cannot be less than 0")
      .max(100, "Insurance percentage cannot be greater than 100")
      .nullable(),
  });

  console.log(personName);
  const handleback = () => {
    window.history.back();
  };

   const handleCreateTreatment = async () => {
      if (isReferralUser()) return;
      const { value: treatmentName } = await Swal.fire({
        title: "Add Treatment",
        input: "text",
        inputLabel: "Treatment Name",
        inputPlaceholder: "Enter treatment name",
        showCancelButton: true,
        confirmButtonText: "Add",
        inputValidator: (value) => {
          if (!value) {
            return "Treatment name is required";
          }
        },
      });
      if (treatmentName) {
        const payload = { name: treatmentName };
        try {
          const response = await axios.post(
            `${AdminBaseUrl}treatment/add`,
            payload,
          );
            console.log(response.data)
            const data = await response.data;
            console.log(response, data)
          if (response.data.success === "true") {
            dispatch(GetAllTreatment());
            Swal.fire(
              "Success",
              data.message || "Treatment created successfully",
              "success",
            );
          } else {
            Swal.fire(
              "Error",
              data.message || "Failed to create treatment",
              "error",
            );
          }
        } catch (error) {
          console.log(error);
          Swal.fire(
            "Error",
            error?.response?.data?.message ||
              error.message ||
              "Something went wrong",
            "error",
          );
        }
      }
    };
  if (isReferralUser()) return null;

  return (
    <>
      <div className="page-wrapper">
        <div className="content">
          <div className="row">
            <div className="col-md-12">
              <h4 className="page-title">
                <span
                  style={{ cursor: "pointer" }}
                  onClick={() => {
                    handleback();
                  }}
                >
                  <i class="fi fi-sr-angle-double-small-left"></i>
                </span>
                Add Treatment
              </h4>
            </div>
          </div>
          <div className="main_content">
            <Formik
              initialValues={{
                patientId: location?.state?.patient || "",
                treatment_course_id: "",
                treatment_course_name: "",
                total_charge: "",
                discount_percentage: "",
                final_amount: "",
                commission_percentage: 10,
                insurance_percentage: "",
                services: "",
                paymentMethod: "",
                Currency: "USD",
              }}
              validationSchema={basicSchema}
              onSubmit={async (values, { setSubmitting }) => {
                console.log("Submitted Values:", values);
                try {
                  const comm =
                    values.commission_percentage !== "" &&
                    values.commission_percentage !== null &&
                    values.commission_percentage !== undefined
                      ? Number(values.commission_percentage)
                      : 10;
                  const payload = {
                    ...values,
                    total_charge: Number(values.total_charge),
                    commission_percentage: comm,
                    referral_commission_percentage: comm,
                  };
                  if (values.discount_percentage !== "") {
                    payload.discount_percentage = Number(
                      values.discount_percentage,
                    );
                  } else {
                    delete payload.discount_percentage;
                  }
                  if (values.final_amount !== "") {
                    payload.final_amount = Number(values.final_amount);
                  } else {
                    delete payload.final_amount;
                  }
                  if (values.insurance_percentage !== "") {
                    payload.insurance_percentage = Number(values.insurance_percentage);
                  } else {
                    delete payload.insurance_percentage;
                  }
                  const result = await dispatch(
                    AddTretmentForPatient(payload),
                  ).unwrap();

                  const createdTId =
                    result?.treatment_id ||
                    result?.treatmentId ||
                    result?.data?.id ||
                    result?.id ||
                    values.treatment_course_id ||
                    "";

                  saveTreatmentCommissionData({
                    treatmentId: createdTId,
                    patientId: values.patientId,
                    commissionPercentage: comm,
                    insurancePercentage: values.insurance_percentage,
                    totalCharge: values.total_charge,
                    finalAmount: values.final_amount || values.total_charge,
                    treatmentName: values.treatment_course_name,
                  });

                  Swal.fire("Treatment added successfully!", "", "success");
                  navigate("/Admin/Patient-Detail", {
                    state: { patientId: location?.state?.patient },
                  });
                } catch (err) {
                  console.error("Submission Error:", err);
                  Swal.fire(
                    "Error!",
                    err?.message || "An error occurred",
                    "error",
                  );
                }
                setSubmitting(false);
              }}
            >
              {({ values, isSubmitting, setFieldValue }) => (
                <Form>
                  <div className="row">
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Patient ID<span className="text-danger">*</span>
                        </label>
                        <Field
                          className="form-control"
                          type="text"
                          name="patientId"
                        />
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="field-set  ">
                        <div className="d-flex justify-content-between align-items-center">
 <div>
                        <label>
                          Treatment Name<span className="text-danger">*</span>
                        </label>
                        </div>
                        <div>

                          <button
                                  type="button"
                                  className="btn btn-sm btn-primary"
                                  onClick={handleCreateTreatment}
                                  >
                                  + Add
                                </button>
                                  </div>
                        </div>
                       
                        <Autocomplete
                          disablePortal
                          options={Treatment || []}
                          getOptionLabel={(option) => option.name || ""}
                          isOptionEqualToValue={(option, value) =>
                            option.id === value.id
                          }
                          onChange={(e, value) => {
                            setFieldValue(
                              "treatment_course_id",
                              value ? value.id : "",
                            );
                            setFieldValue(
                              "treatment_course_name",
                              value ? value.name : "",
                            );
                          }}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              placeholder="Select Treatment"
                            />
                          )}
                          sx={{
                            "& .MuiOutlinedInput-root": {
                              padding: "0px",
                              "&:hover fieldset": {
                                borderColor: "#ced4da",
                              },
                            },
                          }}
                        />

                        <ErrorMessage
                          name="treatment_course_id"
                          component="div"
                          style={{ color: "red" }}
                        />
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Total Charge<span className="text-danger">*</span>
                        </label>
                        <div className="fixpricee">
                          <p className="code-dial">USD($)</p>
                          <Field
                            className="form-control code-in"
                            type="number"
                            name="total_charge"
                            min="0"
                            step="any"
                            onChange={(event) => {
                              const value = event.target.value;
                              setFieldValue("total_charge", value);
                              if (values.discount_percentage !== "") {
                                setFieldValue(
                                  "final_amount",
                                  calculateFinalAmount(
                                    value,
                                    values.discount_percentage,
                                  ),
                                );
                              } else if (values.final_amount !== "") {
                                setFieldValue(
                                  "discount_percentage",
                                  calculateDiscountPercentage(
                                    value,
                                    values.final_amount,
                                  ),
                                );
                              }
                            }}
                          />
                        </div>
                        <ErrorMessage
                          name="total_charge"
                          component="div"
                          style={{ color: "red" }}
                        />
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>Discount (%)</label>
                        <Field
                          className="form-control"
                          type="number"
                          name="discount_percentage"
                          min="0"
                          max="100"
                          step="any"
                          onChange={(event) => {
                            const value = event.target.value;
                            setFieldValue("discount_percentage", value);
                            if (value !== "") {
                              setFieldValue(
                                "final_amount",
                                calculateFinalAmount(
                                  values.total_charge,
                                  value,
                                ),
                              );
                            }
                          }}
                        />
                        <ErrorMessage
                          name="discount_percentage"
                          component="div"
                          style={{ color: "red" }}
                        />
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>Final Amount</label>
                        <div className="fixpricee">
                          <p className="code-dial">USD($)</p>
                          <Field
                            className="form-control code-in"
                            type="number"
                            name="final_amount"
                            min="0"
                            step="any"
                            onChange={(event) => {
                              const value = event.target.value;
                              setFieldValue("final_amount", value);
                              if (value !== "") {
                                setFieldValue(
                                  "discount_percentage",
                                  calculateDiscountPercentage(
                                    values.total_charge,
                                    value,
                                  ),
                                );
                              }
                            }}
                          />
                        </div>
                        <ErrorMessage
                          name="final_amount"
                          component="div"
                          style={{ color: "red" }}
                        />
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Services<span className="text-danger">*</span>
                        </label>
                        <Autocomplete
                          multiple
                          options={Service.map(
                            (service) => service.serviceName,
                          )}
                          onChange={(event, value) => {
                            const selectedIds = value.map(
                              (name) =>
                                Service.find(
                                  (service) => service.serviceName === name,
                                )?.serviceId,
                            );
                            setPersonName(value);
                            setFieldValue("services", selectedIds);
                          }}
                          renderInput={(params) => (
                            <TextField {...params} label="Select Services" />
                          )}
                          value={personName}
                          size="small"
                          sx={{
                            "& .MuiOutlinedInput-root": {
                              padding: "0px",
                              "&:hover fieldset": {
                                borderColor: "#ced4da",
                              },
                            },
                          }}
                        />
                        <ErrorMessage
                          name="services"
                          component="div"
                          style={{ color: "red" }}
                        />
                      </div>
                    </div>

                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Referral Commission (%) <span className="text-muted">(On Paid Bill)</span>
                        </label>
                        <div className="fixpricee">
                          <p className="code-dial">%</p>
                          <Field
                            className="form-control code-in"
                            type="number"
                            name="commission_percentage"
                            min="0"
                            max="100"
                            step="any"
                            placeholder="e.g. 10"
                          />
                        </div>
                        <ErrorMessage
                          name="commission_percentage"
                          component="div"
                          style={{ color: "red" }}
                        />
                      </div>
                    </div>

                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Insurance (%) <span className="text-muted">(Claim On Paid Bill)</span>
                        </label>
                        <div className="fixpricee">
                          <p className="code-dial">%</p>
                          <Field
                            className="form-control code-in"
                            type="number"
                            name="insurance_percentage"
                            min="0"
                            max="100"
                            step="any"
                            placeholder="e.g. 15"
                          />
                        </div>
                        <ErrorMessage
                          name="insurance_percentage"
                          component="div"
                          style={{ color: "red" }}
                        />
                      </div>
                    </div>
                  
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Currency<span className="text-danger"></span>
                        </label>
                        <Field
                          className="form-control"
                          type="text"
                          name="Currency"
                        />
                        <ErrorMessage
                          name="Currency"
                          component="div"
                          style={{ color: "red" }}
                        />
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="field-set">
                        <label>
                          Payment Method <span className="text-danger"></span>
                        </label>
                        <Field
                          as="select"
                          name="paymentMethod"
                          className="form-control"
                        >
                          <option value="">Select a payment method</option>
                          <option value="Guarantee of Payment">Guarantee of Payment</option>
                          <option value="Cash">Cash</option>
                          <option value="UPI">Online via UPI</option>
                          <option value="foundation">foundation</option>
                          <option value="Internet banking">
                            Internet Banking
                          </option>
                          <option value="Credit/Debit Card">
                            Debit / Credit Card
                          </option>
                        </Field>
                      </div>
                    </div>
                  </div>
                  <div className="">
                    <button
                      className="submit-btn"
                      type="submit"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? "Submitting..." : "Submit"}
                    </button>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      </div>
    </>
  );
}
